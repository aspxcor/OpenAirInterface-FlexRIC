Bad design decision. Fix it after the Hackfest!!!
