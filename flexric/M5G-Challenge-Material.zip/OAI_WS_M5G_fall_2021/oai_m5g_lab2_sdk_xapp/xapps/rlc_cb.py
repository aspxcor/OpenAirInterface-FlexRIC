# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.

## Authors: Hung NGUYEN, OAI - M5G

import sys
sys.path.append('./src')
import logging
import json

from sdk.xapp_base import Xappbase
from sdk.constants import Ind
import asyncio
import sdk.comm_layer as comm_layer

from sdk.utils import do_nothing, pdcp_attr, mac_attr, rlc_attr

import sdk.api as api
from sdk import context



class Xapp(Xappbase):
    """ This is the template of xapp you develop 
    """
    def __init__(self, conf):
        """ Set up your app with which services you would like to subscribe
            and launch all the attributes that helps your app functional.

            Args:
                conf: configuration of your app (user-defined)
        """
        period_to_run_logic = 10 # seconds
        # log level is info
        super().__init__(
            period_to_run_logic,
            log_level=logging.DEBUG, 
            ping_timeout=conf['connection_timeout'],
            ## best practise: 
            # set record = True first, then comment out record and set simulation to True 
            record=False,
            simulation = False,
            # don't trigger periodic func for this xapp
            trigger_periodic_func=False
            )

        # pick the services you would like to get the report
        self.report(Ind.MAC)
        self.report(Ind.RLC, self.rlc_message_handler)
        self.report(Ind.PDCP)

        self.count = 0
 
    
    def rlc_message_handler(self, rlc_msg):
        """ OPTIONAL: user defined 
            logic you would like to do with rlc_msg before 
            runing the periodic logic, user define function
            
            Args:
                rlc_msg: a data_layer.RLC instance for rlc message
        """
        if self.count % 250 == 0:
            json_content = rlc_msg.toJSON()
            self.log.info(f"{json_content}")
            with open("./data/rlc/" +  str(rlc_msg.tstamp) + '.json', 'w') as f:
                json.dump(json_content, f)
        self.count += 1

async def main():
    ### HERE IS HOW YOU SHOULD CALL YOUR APPS

    # set up your conf for your app
    conf = {
        'connection_timeout' : 3,
        'running_time': 30,
    }
    
    # create the app
    xapp = Xapp(conf)
    # trigger the app 
    await xapp.run()

    # keep your xapp run some time 
    # HERE it runs for 60s
    await asyncio.sleep(conf["running_time"])

    # after 60s, trigger stop periodic and stop xApp
    # you can add some conditions here to terminate the apps
    xapp.stop()


## DON'T CHANGE THIS    
if __name__ == "__main__":
    asyncio.run(main())