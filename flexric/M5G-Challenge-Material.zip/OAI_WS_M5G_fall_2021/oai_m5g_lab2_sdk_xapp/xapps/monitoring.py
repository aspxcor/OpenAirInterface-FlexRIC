# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.

## Authors: Hung NGUYEN, OAI - M5G

import sys
sys.path.append('./src')
import logging

from sdk.xapp_base import Xappbase
from sdk.constants import Ind
import asyncio
import sdk.comm_layer as comm_layer

from sdk.utils import do_nothing, pdcp_attr, mac_attr, rlc_attr

import sdk.api as api
from sdk import context

class Xapp(Xappbase):
    """ This is the template of xapp you develop 
    """
    def __init__(self, conf):
        """ Set up your app with which services you would like to subscribe
            and launch all the attributes that helps your app functional.

            Args:
                conf: configuration of your app (user-defined)
        """
        period_to_run_logic = 10 # seconds

        # log level is info
        super().__init__(
            period_to_run_logic,
            log_level=logging.DEBUG, 
            ping_timeout=conf['connection_timeout'],
            ## best practise: 
            # set record = True first, then comment out record and set simulation to True 
            record = False,
            simulation = False,
            # don't trigger periodic func for this xapp
            trigger_periodic_func=True
            )

        # subscribe for the services
        self.report(Ind.MAC, self.mac_message_handler)
        self.report(Ind.RLC, self.rlc_message_handler)
        self.report(Ind.PDCP, self.pdcp_message_handler)

        # set up any variable for holding your temporary data, xapp data ,etc HERE.
        self.ue_rntis = set()

        # interested ue id
        self.interested_ue_id = 0
        self.mac_recv = 0
        self.rlc_recv = 0
        self.pdcp_recv = 0 

        
    def mac_message_handler(self, mac_msg):
        """ OPTIONAL: user defined 
            logic you would like to do with mac_msg before 
            runing the periodic logic, user define function
            
            Args:
                mac_msg: a data_layer.MAC instance for mac message
        """
        self.log.debug(f" xapp msg received MAC: {mac_msg}")

        ## adding ue_rnti to the context of xApp
        self.ue_rntis.add(mac_msg.rnti)

        self.mac_recv+= 1
        return 0

    def rlc_message_handler(self, rlc_msg):
        """ OPTIONAL: user defined 
            logic you would like to do with rlc_msg before 
            runing the periodic logic, user define function
            
            Args:
                mac_msg: a data_layer.RLC instance for rlc message
        """
        self.log.debug(f" xapp msg received RLC: {rlc_msg}")
        
        ## adding ue_rnti to the context of xApp
        self.ue_rntis.add(rlc_msg.rnti)
        self.rlc_recv +=1 
        return 0
        
    def pdcp_message_handler(self, pdcp_msg):
        """ OPTIONAL: user defined 
            logic you would like to do with pdcp_msg before 
            runing the periodic logic, user define function
            
            Args:
                pdcp_msg: a data_layer.PDCP instance for pdcp message
        """
        self.log.debug(f" xapp msg received PDCP: {pdcp_msg}")

        ## adding ue_rnti to the context of xApp
        self.ue_rntis.add(pdcp_msg.rnti)
        self.pdcp_recv += 1
        return 0

    def run_periodic(self, *args, **kwargs):
        """ This function will call every self.period seconds to
            do your logic. 
        """
        ######## YOUR LOGIC SHOULD BE HERE ########

        # THIS IS AN EXAMPLE

        if api.number_connected_ue():
            # get single item from ue_rntis
            all_ue_id = api.connected_ue_ids(enb=0)
            ue_id = all_ue_id[0]
            self.log.info(f'Number of connected UEs: {api.number_connected_ue()}')
            self.log.info(f'RNTI of connected UEs: {api.connected_ue_ids()}')
            self.log.info(f'Number of stored pdcp msg received from the 1st UE: {api.num_pdcp_pkg(ue_id)}')
            self.log.info(f'Number of stored rlc msg received from the 1st UE: {api.num_rlc_pkg(ue_id)}')
            self.log.info(f'Number of stored mac msg received from the 1st UE: {api.num_mac_pkg(ue_id)}')

            ## get some attributes that you care about here.
            ## if you want to get all attribute of MAC SM, simply use:
            ##   attr=utils.mac_attr()
            ## Similarly, we have: 
            ##   attr=utils.rlc_attr()
            ##   attr=utils.pdcp_attr()
            pdcp_stats = api.get_attr(attr=["pdcp.rnti", "pdcp.tstamp", "pdcp.txpdu_bytes", "pdcp.rxpdu_bytes"], 
                                        windows=3)
            self.log.info(f'pdcp: {pdcp_stats}')

            rlc_stats = api.get_attr(attr=["rlc.rnti", "rlc.tstamp", "rlc.txpdu_bytes", "rlc.txpdu_retx_pkts"], 
                                        windows=3)
            self.log.info(f'rlc: {rlc_stats}')

            mac_stats = api.get_attr(attr=["mac.rnti", "mac.tstamp", "mac.dl_aggr_tbs", "mac.ul_aggr_tbs"], 
                                        windows=3)
            self.log.info(f'mac: {mac_stats}')
            
            if not self.simulation:
                ## This stats are only valid when we run with real RIC
                # Not on the simulation mode.  
                self.log.info(f'Number of Mac msg received recv so far: {self.mac_recv}')
                self.log.info(f'Number of RLC msg received recv so far : {self.rlc_recv}')
                self.log.info(f'Number of PDCP msg received recv so far : {self.pdcp_recv}')

        else:
            self.log.info("No ue connected")        

async def main():
    ### HERE IS HOW YOU SHOULD CALL YOUR APPS

    # set up your conf for your app
    conf = {
        'connection_timeout' : 3,
        'running_time': 30,
    }
    
    # create the app
    xapp = Xapp(conf)
    # trigger the app 
    await xapp.run()

    # keep your xapp run some time 
    # HERE it runs for 60s
    await asyncio.sleep(conf["running_time"])

    # after 60s, trigger stop periodic and stop xApp
    # you can add some conditions here to terminate the apps
    xapp.stop()

## DON'T CHANGE THIS    
if __name__ == "__main__":
    asyncio.run(main())