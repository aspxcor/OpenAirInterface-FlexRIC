# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.

## Authors: Hung NGUYEN, OAI - M5G

from collections import defaultdict
import logging
from itertools import islice
import time
import sys

from . import data_layer 

import pickle 
import threading

from .utils import str_to_ind

from pathlib import Path
from sdk import sdk_conf

# SDK context
SDK_context = [defaultdict(data_layer.UE)]
SDK_context_UEID = [[]]

iteration = 0
log = logging.getLogger("CONTEXT")

SIMULATION = False
current_time_tamp = 0
number_TTI_in_each_period = 5
NEXT_SESSION_ID = 0

RECORDING = False

session = None

LAST_SESSION_KEY = 'last_session'
lock = threading.Lock()


def get_next_id_session():
    return 0

def get_cached_data():
    return 0

def cache_last_session():
    with open(sdk_conf.M5G_CACHE, 'wb') as f:
        pickle.dump({ LAST_SESSION_KEY : session}, f)

def activate_recording():
    # create a new session

    # make a new directory
    timestr = time.strftime("%Y%m%d.%H%M%S")
    global session, RECORDING
    session = Path(sdk_conf.M5G_LOG_PATH + "/session_" + timestr)
    session.mkdir(parents=True, exist_ok=False)
    RECORDING = True

def activate_simulation():
    log.info("SIMULATION mode is ON")
    SIMULATION = True
    log.debug("Loading the recording data")
    iteration = get_cached_data()
    load_context()

def deactivate_simulation():
    log.info("SIMULATION mode is OFF")
    SIMULATION = False

def add_ueid_to_context(rnti, enb=0):
    if rnti not in SDK_context_UEID[enb]:
        SDK_context_UEID[enb].append(rnti)

def add_mac_to_context(indication):
    with lock:
        log.debug(f"Adding mac to {indication.rnti}")
        add_ueid_to_context(indication.rnti)
        SDK_context[0][indication.rnti].add_mac(indication)

def add_rlc_to_context(indication):
    with lock:
        log.debug(f"Adding rlc to {indication.rnti}")
        add_ueid_to_context(indication.rnti)
        SDK_context[0][indication.rnti].add_rlc(indication)

def add_pdcp_to_context(indication):
    with lock:
        log.debug(f"Adding pdcp to {indication.rnti}")
        add_ueid_to_context(indication.rnti)
        SDK_context[0][indication.rnti].add_pdcp(indication)

def id_to_rnti(ue_id, enb=0):
    if 0<=ue_id<len():
        return SDK_context_UEID[enb][ue_id]
    else:
        log.error(f"Invalid id for ue in context: {ue_id}")

def save_current_context():
    if not RECORDING:
        return
    with lock:
        with open(str(session) + f'/context.pkl', 'wb') as outp:
            pickle.dump({'context': SDK_context, 'ids': SDK_context_UEID}, outp)
    cache_last_session()
    log.info("Saved context to file")

def load_context():
    cache_file = None
    if not sdk_conf.RELAX_CONDITION:
        if not Path(sdk_conf.M5G_CACHE).exists():
            log.error("You don't have any recored session. Please run your xApp"
                    " with recording=True for a session then run back this "
                    "simulation later.")
            sys.stdout.flush()
            sys.exit()

        with open(sdk_conf.M5G_CACHE, 'rb') as f:
            last_session = pickle.load(f)[LAST_SESSION_KEY]
        if last_session is None:
            log.error("You don't have any recored session. Please run your xApp"
                    " with recording=True for a session then run back this "
                    "simulation later.")
            sys.stdout.flush()
            sys.exit()
        cache_file = Path(str(last_session) + '/context.pkl')
    else:
        log.info("The condition to use SIMULATION mode is relaxed.")
        cache_file = Path(sdk_conf.DEFAULT_CONTEXT_SIMULATION)

    if cache_file.exists():
        with open(str(cache_file), 'rb') as inp:
            fake_context = pickle.load(inp)
            SDK_context[0].update(fake_context['context'][0])
            SDK_context_UEID[0].extend(fake_context['ids'][0])
            log.info(SDK_context_UEID)
            log.info(SDK_context)
        log.info("Loaded context from file")
    else:
        log.error("Your recored session doesn't exist. It might be deleted by accident. Please run your xApp"
                  " with recording=True for a session then run back this "
                  "simulation later.")

def get_context_item(end_id, ue_id, windows, service_model):
    assert service_model in ['mac', 'rlc', 'pdcp']
    return SDK_context[end_id][ue_id].get_last_n_items(windows, str_to_ind(service_model))
