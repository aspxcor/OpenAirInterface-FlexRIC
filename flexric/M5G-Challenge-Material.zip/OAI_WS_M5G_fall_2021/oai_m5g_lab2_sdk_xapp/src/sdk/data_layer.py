# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.

## Authors: Hung NGUYEN, OAI - M5G

from enum import Enum
from itertools import islice
from .constants import MAC_SUPPORTED_ATTR, PDCP_SUPPORTED_ATTR, RLC_SUPPORTED_ATTR, Ind
import logging
import json

from collections import deque

log = logging.getLogger("DATA")

def validate_message(msg):
    if "=" not in msg:
        return False
    if len(msg) <=3:
        return False
    if msg.startswith("=") or msg.endswith('='):
        return False
    return True

def str_to_num(s):
    try:
        return int(s) if s.isdigit() else float(s)
    except ValueError:
        log.error(f"Invalid value of attribute in the message, expected an positive number, get {s}")
        return -1

def set_attr_val_to_object(object, msg):
    msg = msg[msg.index(':') + 1:].strip()
    
    attr_val_pairs = msg.split(',')
    for attr_val_pair in attr_val_pairs:
        if validate_message(attr_val_pair):
            attr, val = attr_val_pair.split('=')
            if hasattr(object, attr):
                val = str_to_num(val)
                setattr(object, attr, val)
            else:
                log.error(f"invalid set attr : {attr} for class: {object.__class__.__name__}")
                pass 
    return object

def set_default_val(object, attr_list, val = 0):
    for attr in attr_list:
        setattr(object, attr, val)
    return object

class Direction(Enum):
    UP = 1
    DOWN = 2

class RLC:
    def __init__(self) -> None:
        set_default_val(self, RLC_SUPPORTED_ATTR)
    
    def toJSON(self):
        return json.dumps(self, default=lambda o: o.__dict__, 
            sort_keys=True, indent=4)

def msg_to_rlc(msg): 
    rlc = RLC()
    return set_attr_val_to_object(rlc, msg)

class MAC:
    def __init__(self) -> None:
        set_default_val(self, MAC_SUPPORTED_ATTR)
    
    def toJSON(self):
        return json.dumps(self, default=lambda o: o.__dict__, 
            sort_keys=True, indent=4)

def msg_to_mac(msg):
    mac = MAC()
    return set_attr_val_to_object(mac, msg) 

class Pdcp:
    def __init__(self) -> None:
        set_default_val(self, PDCP_SUPPORTED_ATTR)
    
    def toJSON(self):
        return json.dumps(self, default=lambda o: o.__dict__, 
            sort_keys=True, indent=4)
    
def msg_to_pdcp(msg):
    pdcp = Pdcp()
    return set_attr_val_to_object(pdcp, msg)


class Enb:
    """
    Bs_id: base station id
    Ues : list of UEs 
    Cells: List of Cells
    """
    def __init__(self) -> None:
        self.ues = []
        self.bs_id = []
        self.cells = []
      
    def ue(self, ue_id: int):
        """ Returns the UE object indexed at enb_id
        """
        pass

    def cell(self, id: int):
        """ Returns cell object indexed at id
        """
        pass  
    
    def sfr(self):
        pass


class UE: 
    """ Object contains all info about UE
    """
    def __init__(self, max_size_queue = 1000) -> None:
        self.conf = None

        self.rlcs = deque(maxlen=max_size_queue)
        self.macs = deque(maxlen=max_size_queue) 
        self.pdcps = deque(maxlen=max_size_queue)

        self.rnti = 0
        self.imsi = 0
        self.phr = 0

    def conf(self):
        """  returns the conf for ue
        """
        return self.conf

    def rnti(self):
        return self.rnti

    def imsi(self):
        return self.imsi 

    def phr(self):
        return self.phr 

    def mac(self):
        return self.mac

    def pdcp(self):
        return self.pdcp

    def rlc(self, lc):
        """Returns the ENB object of indexed at lc
        """
        return self.rlcs

    def neighbor_cells(self):
        """ Returns a list of cell IDs
        """
     
    def dlCqi(self):
        pass 

    def dlwbcqi(self):
        pass 

    def bsr(self, lc : int):
        pass

    def add_mac(self, mac):
        self.macs.appendleft(mac)

    def add_pdcp(self, pdcp):
        self.pdcps.appendleft(pdcp)
    
    def add_rlc(self, rlc):
        self.rlcs.appendleft(rlc)

    def get_last_n_items(self, n, type):
        if type == Ind.MAC:
            return list(islice(self.macs, 0, n))
        elif type == Ind.RLC:
            return list(islice(self.rlcs, 0, n))
        else:
            return list(islice(self.pdcps, 0, n))

class Cell:
    def __init__(self) -> None:
        self.dlBandwidth = None
        self.ulBandwidth = None
        self.phyId = None
        self.maxMCS = None 

    def x2HoNetControl(self):
        pass

    def bw(self, dir):
        pass 

    def resource_group_block(self, dir):
        pass 

    def freq(self, dir):
        pass
    
    def power(self, dir):
        pass
    
    def band(self):
        pass