# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.

## Authors: Hung NGUYEN, OAI - M5G

import time
import sys
from threading import Thread
import threading
import logging
import asyncio
import sys

import pynng
from pynng import Pub0, Sub0, Timeout

from .sdk_conf import timeout, address_msg, address_ping, pubsub_address
from .constants import INIT, KEEP_ALIVE, META, Ind
from . import utils, context, data_layer

# global settings for SDK
log = None
sock_ping = pynng.Req0(send_timeout = timeout, recv_timeout = timeout) 
sock_msg = pynng.Req0(send_timeout = timeout, recv_timeout = timeout)

RUNNING = True

# Pools
QUEUE_POOL = {x : asyncio.Queue() for x in META.keys()}
SUB_POOL = {}
STATE_POOL = {x : False for x in META.keys()}
TASK_POOL = {x : None for x in META.keys()}
COUNTER = {x : 0 for x in META.keys()}
stop_event= threading.Event()

id_xApp = None

def validate_rnti(rnti):
    return rnti >= 0

def send_ping(msg_send):
    try:
        log.debug("[PING SEND] " + msg_send)
        sock_ping.send(msg_send.encode())
    except pynng.exceptions.Timeout:
        log.error("Send ping to RIC: Timeout")
        self_stop()


def send_msg(msg_send):
    try:
        log.debug("[MSG  SEND] " + msg_send)
        sock_msg.send(msg_send.encode())
    except pynng.exceptions.Timeout:
        log.error("Send msg to RIC: Timeout")
        self_stop()

def ping_recv():
    msg = sock_ping.recv_msg()
    log.debug("[PING RECV] " + msg.bytes.decode())
    return msg.bytes.decode()

def msg_recv():
    try:
        msg = sock_msg.recv_msg()
        log.debug("[MSG RECV] " + msg.bytes.decode())
        return msg.bytes.decode()
    except pynng.exceptions.Timeout:
        log.info('[GLOBAL] Connection to the RIC is temporary closed')
        self_stop()
        return None

def ping(idxapp, stop_event):
    msg_send = utils.make_ping(idxapp)
    while not stop_event.is_set():
        try:
            send_ping(msg_send)
            startTime = time.time()
            msg = ping_recv()
            executionTime = (time.time() - startTime)
            log.debug('[GLOBAL] Latency in seconds: ' + str(executionTime))
            time.sleep(3)
        except pynng.exceptions.Timeout:
            log.error('[GLOBAL] Connection to the RIC has lost.')
            self_stop()
        except pynng.exceptions.Closed:
            log.error('[GLOBAL] Connection to the RIC closed.')
            self_stop()

def init():
    global log
    log = logging.getLogger("COMM")
    try:
        global SUB_POOL
        SUB_POOL = {x : Sub0(dial=pubsub_address, recv_timeout=timeout) for x in META.keys()}
        sock_ping.dial(address_ping)
        log.debug(f"[NODE1] ASKING FOR ID")
        send_ping(INIT)
        msg = ping_recv()
        _id_xApp = msg 
        if len(_id_xApp) <2:
            ## expect the msg contains at least 2 chars
            log.error("len of id xApp is too short, it should cotains at least 2 chars.")    
        global id_xApp
        id_xApp = _id_xApp[:-1]
        log.debug(f"[GLOBAL] xAPP ID = {id_xApp}")
        log.info("CONNECTED TO RIC")

    except pynng.exceptions.Timeout:
        log.error("Timeout, RIC not reacheable, exiting")
        self_stop()
        
    # THREAD VERSION
    ping_thread = Thread(target = ping, args =(id_xApp, stop_event), daemon = True)
    ping_thread.start()

    # =======
    # asyncio version
    sock_msg.dial(address_msg)


def report_stats(str_req):
    msg_send = utils.make_report(id_xApp, str_req)
    send_msg(msg_send)
    msg_str = msg_recv()
    if msg_str:
        assert(msg_str == 'ANSWER_OK\x00')
        #TODO: handle failed cases
        return "OK"
    else: 
        return "FAILED"

async def tasking(funct, msg_type):
    log.debug(f"msg_type: {msg_type} type: {str(type(msg_type))}")
    while RUNNING:
        try:
            if STATE_POOL[msg_type]: 
                msg = await SUB_POOL[msg_type].arecv_msg()
                msg = msg.bytes.decode()[:-1]
                global SDK_context
                log.debug(msg)
                indication = None
                if msg_type == 'MAC':
                    indication = data_layer.msg_to_mac(msg)
                    if validate_rnti(indication.rnti):
                        context.add_mac_to_context(indication)
                    else:
                        log.debug(f"RLC rnti < 0: {indication.rnti}")
                elif msg_type == 'PDCP':
                    indication = data_layer.msg_to_pdcp(msg)
                    if validate_rnti(indication.rnti):
                        context.add_pdcp_to_context(indication)
                    else:
                        log.debug(f"PDCP rnti < 0: {indication.rnti}")
                elif msg_type == 'RLC':
                    indication = data_layer.msg_to_rlc(msg)
                    if validate_rnti(indication.rnti):
                        context.add_rlc_to_context(indication)
                    else:
                        log.debug(f"RLC rnti < 0: {indication.rnti}")
                if indication:
                    funct(indication)

        except asyncio.CancelledError:
            log.debug(f"[GLOBAL] Task {msg_type} cancelled")
            return
        except pynng.exceptions.Timeout:
            log.error('[GLOBAL] No data from the subscription received!')
        
def subcribe_type_stats(funct,msg_type, interval):
    log.debug(f"val : {id_xApp}")
    if isinstance(msg_type, Ind): 
        msg_type = msg_type.name
    log.debug(f"msg type : {msg_type}")
    ans = report_stats(utils.make_request_message(msg_type, interval))
    assert(ans == "OK")
    if ans != "OK":
        log.debug(f"[GLOBAL] CANNOT SUBSCRIBE {msg_type} stats")
        pass
    #TODO: handle errors

    SUB_POOL[msg_type].subscribe(META[msg_type]['str_stats'])
    global STATE_POOL, TASK_POOL
    STATE_POOL[msg_type] = True  

    # Task version
    if not TASK_POOL[msg_type]:
        TASK_POOL[msg_type] = asyncio.create_task(tasking(funct, msg_type))
    
    log.debug(f"[GLOBAL] SUBSCRIBE {msg_type} stats")


def unsubcribe_type_stats(msg_type):
    log.debug(f"[GLOBAL] REMOVING {msg_type} stats")
    SUB_POOL[msg_type].unsubscribe(META[msg_type]['str_stats'])
    STATE_POOL[msg_type] = False
    
def make_func_stats(msg_type):
    def func_stats(data_str):
        COUNTER[msg_type]+=1
        log.debug(f"From {msg_type} stats function {data_str}")
    return func_stats

def self_stop():
    stop_event.set()
    global STATE_POOL
    for x in STATE_POOL:
        STATE_POOL[x] = False

    for x in TASK_POOL:
        if TASK_POOL[x]:
            TASK_POOL[x].cancel()
    
    global RUNNING
    RUNNING = False
    sys.stdout.flush()
    log.debug('[Global] SDK COMM Terminated')
    sys.exit()
    
def trigger_task():
    asyncio.gather(*TASK_POOL.values())
