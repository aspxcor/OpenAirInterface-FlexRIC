# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.

## Authors: Hung NGUYEN, OAI - M5G

from .constants import KEEP_ALIVE, MAC_SUPPORTED_ATTR, PDCP_SUPPORTED_ATTR, RLC_SUPPORTED_ATTR, Ind

def make_request_message(message_type, interval = 10):
    return f"REQUEST;REPORT={message_type};INTERVAL={interval}"

def make_report(id_xApp, str_req):
    return "ID=" + str(id_xApp) + ';' + str_req + ';' 

def make_ping(idxapp):
    return "ID=" + idxapp + ';' + str(KEEP_ALIVE)

def do_nothing(msg):
    pass 

def mac_attr():
    return ["mac." + x for x in MAC_SUPPORTED_ATTR]

def pdcp_attr():
    return ["pdcp." + x for x in PDCP_SUPPORTED_ATTR]

def rlc_attr():
    return ["rlc." + x for x in RLC_SUPPORTED_ATTR]

def str_to_ind(s):
    if s == "mac":
        return Ind.MAC

    if s == "pdcp":
        return Ind.PDCP

    if s == "rlc":
        return Ind.RLC
