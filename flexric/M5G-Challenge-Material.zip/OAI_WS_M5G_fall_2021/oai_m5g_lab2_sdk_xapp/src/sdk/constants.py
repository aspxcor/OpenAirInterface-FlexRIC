# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.


## Authors: Hung NGUYEN, OAI - M5G

from enum import Enum

INIT = "INIT "
KEEP_ALIVE = "PING "    

META = {
    "MAC" : {
        'REQUEST' : "REQUEST;REPORT=MAC;INTERVAL=10",
        'str_stats' : 'mac_stats',
    },
    "RLC" : {
        'REQUEST' : "REQUEST;REPORT=RLC;INTERVAL=10",
        'str_stats' : 'rlc_stats',
    },
    "PDCP" : {
        'REQUEST' : "REQUEST;REPORT=PDCP;INTERVAL=10",
        'str_stats' : 'pdcp_stats',
    },
}

EXTRACTED_MAC_SAMPLE_MSG = "tstamp=1639063753595265,dl_aggr_tbs=1987221,ul_aggr_tbs=760889,dl_aggr_bytes_sdus=0,ul_aggr_bytes_sdus=0,pusch_snr=21,pucch_snr=21,rnti=14575,dl_aggr_prb=81878,ul_aggr_prb=32797,dl_aggr_sdus=16183,ul_aggr_sdus=6403,dl_aggr_retx_prb=0,wb_cqi=0,dl_mcs1=9,ul_mcs1=0,dl_mcs2=0,ul_mcs2=0,phr=40"

MAC_SUPPORTED_ATTR = [x.split("=")[0] for x in EXTRACTED_MAC_SAMPLE_MSG.split(",")]

EXTRACTED_RLC_SAMPLE_MSG = ("tstamp=1639063753665936,txpdu_pkts=9597,txpdu_bytes=592079,txpdu_wt_ms=0,txpdu_dd_pkts=0,txpdu_dd_bytes=0,txpdu_retx_pkts=3193,txpdu_retx_bytes=290563,txpdu_segmented=0,txpdu_status_pkts=3196,txpdu_status_bytes=9588,txbuf_occ_bytes=0,txbuf_occ_pkts=0,rxpdu_pkts=6403,rxpdu_bytes=297134,rxpdu_dup_pkts=0,rxpdu_dup_bytes=0,rxpdu_dd_pkts=0,rxpdu_dd_bytes=0,rxpdu_ow_pkts=0,rxpdu_ow_bytes=0,rxpdu_status_pkts=3205,rxpdu_status_bytes=9615,rxbuf_occ_bytes=0,rxbuf_occ_pkts=0,txsdu_pkts=3197,txsdu_bytes=277923,rxsdu_pkts=3208,rxsdu_bytes=282304,rxsdu_dd_pkts=0,rxsdu_dd_bytes=0,rnti=14575,mode=0,rbid=1")

RLC_SUPPORTED_ATTR = [x.split("=")[0] for x in EXTRACTED_RLC_SAMPLE_MSG.split(",")]

EXTRACTED_PDCP_SAMPLE_MSG="tstamp=1639063753745915,txpdu_pkts=3209,txpdu_bytes=282392,txpdu_sn=3208,rxpdu_pkts=3198,rxpdu_bytes=278010,rxpdu_sn=3197,rxpdu_oo_pkts=0,rxpdu_oo_bytes=0,rxpdu_dd_pkts=0,rxpdu_dd_bytes=0,rxpdu_ro_count=0,txsdu_pkts=3198,txsdu_bytes=268416,rxsdu_pkts=3209,rxsdu_bytes=272765,rnti=14575,mode=0,rbid=1"

PDCP_SUPPORTED_ATTR = [x.split("=")[0] for x in EXTRACTED_PDCP_SAMPLE_MSG.split(",")]

MAC_SAMPLE_MSG = META["MAC"]['str_stats'] + ": " + EXTRACTED_MAC_SAMPLE_MSG
RLC_SAMPLE_MSG = META["RLC"]['str_stats'] + ": " + EXTRACTED_RLC_SAMPLE_MSG
PDCP_SAMPLE_MSG = META["PDCP"]['str_stats'] + ": " + EXTRACTED_PDCP_SAMPLE_MSG

INDICATORS_LIST = ["mac." + x for x in MAC_SUPPORTED_ATTR] + ["rlc." + x for x in RLC_SUPPORTED_ATTR] + ["pdcp." + x for x in PDCP_SUPPORTED_ATTR]

class Ind(Enum):
    MAC = 1
    RLC = 2
    PDCP = 3 
