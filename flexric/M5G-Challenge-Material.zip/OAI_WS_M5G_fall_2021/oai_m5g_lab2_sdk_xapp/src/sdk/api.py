# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.

## Authors: Hung NGUYEN, OAI - M5G

## SDK context
from collections import defaultdict
import logging

from .constants import MAC_SAMPLE_MSG, MAC_SUPPORTED_ATTR, PDCP_SAMPLE_MSG, PDCP_SUPPORTED_ATTR, RLC_SAMPLE_MSG, INDICATORS_LIST, RLC_SUPPORTED_ATTR, Ind
from .data_layer import MAC, RLC, Pdcp, UE, msg_to_mac, msg_to_pdcp, msg_to_rlc
from . import context


LOCAL_CONTEXT = {
    "mac" : MAC_SUPPORTED_ATTR,
    "rlc" : RLC_SUPPORTED_ATTR,
    "pdcp" : PDCP_SUPPORTED_ATTR
} 

log = logging.getLogger('API')

def _isinstance_list_of_list(object):
    return all([isinstance(x, list) for x in object])

def get_attr(obj, sm, attr):
    return getattr(getattr(obj, sm),attr)

def has_attr(obj, sm, index, attr):
    sm = sm + "s"
    return hasattr(obj, sm) and hasattr(getattr(obj, sm)[index],attr)

def number_connected_ue(enb=0):
    return len(context.SDK_context_UEID[enb])

def connected_ue_rnti(enb=0):
    return context.SDK_context_UEID[enb]

def connected_ue_ids(enb=0):
    return connected_ue_rnti(enb)

def num_mac_pkg(rnti, enb=0):
    return len(context.SDK_context[enb][rnti].macs)

def num_pdcp_pkg(rnti, enb=0):
    return len(context.SDK_context[enb][rnti].pdcps)

def num_rlc_pkg(rnti, enb=0):
    return len(context.SDK_context[enb][rnti].rlcs)

def get_attr(enb = None, ue = None, attr= None, windows = 1, index_is_rnti=False, remove_empty=False):
    """ Get attributes of RIC
        Args:
            enb: index of enb, could be None, an int or list of ints
                None means for every enb
                int: for a specific enb
                list: a list of enb to extract attribute, NOT SUPPORTED YET.

            ue: index of ue
                None means for every ue
                int: get attribute of a given ue 
                    Plan: for every enb  
                list: a list of ue to extract attribute for every enb
                list of list: specific ue for each enb. NOT SUPPORTED YET.
            
            attr: indicator of attributes [1]
                None means for every attributes
                string: get an attribute for every specific ues    
                list[string]: a list of atributes to extract
            
            windows: how many TTI you want to look back to the past
            
            index_is_rnti: whether if index is rnti or simply index of ue in context
            remove_empty: if set True, remvove the empty item in the output

            
           [1] Check the list of indicators HERE. 
        
        Return:
            List[List[List[ (name: List[Value]) : Attributes] : UE infos] : ENB infos]

        Example to use:
        # get every things
        all_stats = get_attr()

        # get every stats for UE 1
        ue1_stats = get_attr(ue=1)

        # get stats uplink mcs2 for every ue
        ul_mcs2_stats = get_attr(attr="mac.ul_mcs2")

        # get stats uplink and downlink mcs2 for every ue
        udl_mcs2_stats = get_attr(attr=["mac.ul_mcs2", "mac.dl_mcs2"])

        # get stats uplink and downlink mcs2 for some ues
        some_ues_udl_mcs2_stats = get_attr(ue = [0,2,4,6,8,10], attr=["mac.ul_mcs2", "mac.dl_mcs2"])
         
    """
    if enb is None:
        enb_indexes = range(len(context.SDK_context))
    elif isinstance(enb, int):
        enb_indexes = [enb]
    elif isinstance(enb, list):
        enb_indexes = enb
    else:
        log.error("[API] type of enb is not supported")
        return []

    log.debug(f"enb indexes: {enb_indexes}")

    if ue is None:
        ue_indexes = [list(range(len(context.SDK_context[x]))) for x in enb_indexes]
        index_is_rnti = False
    elif isinstance(ue, int):
        ue_indexes = [[ue]] * len(enb_indexes)
    elif isinstance(ue, list):
        if _isinstance_list_of_list(ue):
            assert len(ue) == len(enb_indexes), "number of list contains ue must match the number of enb of you want specify each indexes for each enb"
            ue_indexes = ue
        else: 
            ue_indexes = [ue] * len(enb_indexes) 
    else:
        log.error("[API] type of ue is not supported")
    
    log.debug(f"ue indexes: {ue_indexes}")

    if attr is None:
        ##TODO: finish the list of supported strings
        attr_indexes = INDICATORS_LIST
    elif isinstance(attr, str):
        attr_indexes = [attr]
    elif isinstance(attr, list):
        attr_indexes = attr 
    else:
        log.error("[API] type of attr is not supported")

    log.debug(f'attr : {attr_indexes}')
    ## it has better pythonic way to do this
    ## but I do it here so we could clear the instruction
    stats_per_ue = []
    for _id, _enb in enumerate(enb_indexes):
        if _enb < 0 or _enb >= len(context.SDK_context):
            log.error(f"[API] Invalid index of enb must be between 0 and {len(context.SDK_context)}, enb_index: {_enb}")
            if not remove_empty:
                stats_per_ue.append([])
            continue
        ue_stats = []
        
        for ue_id in ue_indexes[_id]:
            if not index_is_rnti:
                if ue_id < 0 or ue_id >= len(context.SDK_context_UEID[_enb]):
                    log.error(f"[API] Invalid index of ue must be between 0 and {len(context.SDK_context_UEID[_enb])}, ue_index: {ue_id}")
                    if not remove_empty:
                        ue_stats.append({})
                    continue
            _ue = ue_id if index_is_rnti else context.SDK_context_UEID[0][ue_id]
            log.debug(f"ue id: {_ue}")
            dict_stats = {}
            for _attr in attr_indexes:
                _sm_attr, _sub_attr = _attr.split(".")
                if _sm_attr not in LOCAL_CONTEXT.keys():
                    log.error(f"[API] Invalid sm attr: {_sm_attr} in {_attr} for enb index: {_enb}, ue_index: {_ue}")
                if _sub_attr not in LOCAL_CONTEXT[_sm_attr]:
                    log.error(f"[API] Invalid attr: {_sub_attr} in {_attr} for enb index: {_enb}, ue_index: {_ue}")

                ue_list = context.get_context_item(_enb, _ue, windows, _sm_attr)
                log.debug(f'{ue_list}')
                
                temp = [getattr(ue, _sub_attr) for ue in ue_list if hasattr(ue, _sub_attr)]
                if temp or (not remove_empty):
                    dict_stats[_attr] = temp
            if dict_stats or (not remove_empty):
                ue_stats.append(dict_stats)
        if ue_stats or (not remove_empty):
            stats_per_ue.append(ue_stats)
    return stats_per_ue

def backup_context():
    context.save_current_context()