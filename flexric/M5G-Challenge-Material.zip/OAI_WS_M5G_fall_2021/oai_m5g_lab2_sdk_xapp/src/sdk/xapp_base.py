# The 3-Clause BSD License
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation 
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its 
#    contributors may be used to endorse or promote products derived from 
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED 
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
# THE POSSIBILITY OF SUCH DAMAGE.

## Authors: Hung NGUYEN, OAI - M5G

import threading
import logging

from . import comm_layer

from .utils import do_nothing

from threading import Event
from sdk import log_sys, context, api


""" Requirements for xApp templates:
        - subscribe for the service they wants
        - unsubscibe for the service they wants
        - callbacks when received messages 
        - periodics functions to do the logic with what data availables.
"""

class Xappbase:
    """ Template for every xapp must follow to take advantages of FlexRIC.
        Handles all necessary set up so that they can focus on logic
    """
    def __init__(self, period=10, log_level = logging.DEBUG, 
                log_format = "%(asctime)s %(name)-12s %(levelname)-8s %(message)s", 
                ric_addr = "", ric_port = "", ping_timeout=5, 
                simulation = False, record = False, 
                trigger_periodic_func=True,
                dont_save_log_to_file = False
                ):
        """ Connect to RIC, handshake and set up to make xApp ready 
            Args:
                period: period to run the logic function of user
                log_level: log level for xapp
                log_format: log format for loggers
                ping_timeout: timeout settings to maintain the connection with RIC,
                               after this timeout, without a ping from your xApp,
                               the connection with RIC is lost.
                simulation: if True, simulate RIC, recommend to use in case don't have access to RIC.
                trigger_periodic_func: if True, trigger periodic function for this xapp.
                dont_save_log_to_file: option for stress test only.
                ric_addr: not supported yet
                ric_port: not supported yet
        """
        assert not(simulation and record), ("You cannot set both simulation and record are True at the same time"
                ". Please set record is True first, then deactivate record, then set simulation to True")
        log_sys.set_log_level(log_level, dont_save_log_to_file)
        self.log = logging.getLogger("XAPP")
        self.period = period
        if not simulation:
            self._register(ric_addr)
        self.stop_periodic_event = Event()
        
        if simulation:
            context.activate_simulation()
            self.log.info("Please note that in the simulation mode, data isn't change."
                         "This mode is for temporary development only.")
        
        if record:
            context.activate_recording()
            self.log.info("Recording mode is ON")

        self.simulation = simulation
        self.trigger_periodic = trigger_periodic_func
        

    def _register(self, ric_addr):
        return comm_layer.init()

    def report(self, msg_type, cfunctor=do_nothing, interval = 10):
        """ subscribe for which services provided by RIC: MAC, PDCP, RLC
            Args:
                msg_type: name of services, one of [MAC, PDCP, RLC]
                cfunctor: call back when receiving the message corresponds with service
                        you would like to register
                interval: SM will send the message each "interval" miliseconds (NOT SUPPORTED YET) 
        """
        if not self.simulation:
            comm_layer.subcribe_type_stats(cfunctor, msg_type, interval=10)

    async def run(self):
        """ launch xapp
        """
        if not self.simulation:
            comm_layer.trigger_task()
        if self.trigger_periodic:
            self._make_periodic(self.run_periodic)

    def remove_report(self, msg_type):
        """ unsubcribe for the subscribed service
            Args:
                msg_type: name of services, one of [MAC, PDCP, RLC]
        """
        if not self.simulation:
            comm_layer.unsubcribe_type_stats(msg_type)
    
    def run_periodic(self):
        """ This function will call each X seconds to do your logic.
            This should be the entry point of your program. 
        """
        self.log.info(f"This function run each {self.period} seconds")
    
    def _make_periodic(self, funct):
        if self.stop_periodic_event.is_set():
            return
        api.backup_context()
        funct()
        t = threading.Timer(self.period, self._make_periodic, args=[funct])
        t.start()
    
    def stop_periodic(self):
        """ Stop periodic function and stop xApp
        """
        if self.trigger_periodic:
            self.log.info("stop periodic function!!!")
            self.stop_periodic_event.set()

    def stop(self):
        if not self.stop_periodic_event.is_set():
            self.stop_periodic()
        self.log.info("XAPP is stopped.")
        if not self.simulation:
            comm_layer.self_stop()